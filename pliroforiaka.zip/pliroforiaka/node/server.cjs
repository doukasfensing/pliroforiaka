"use strict";

const express = require('express');
const { Client } = require("pg");

const app = express();
const port = 3545;

// Keep server running
app.listen(port, () => {
    console.log('Server started on port ' + port);
});

app.get('/', async (req, res) => {
    const client = new Client({
        database: "qdb",
        host: "localhost",
        password: "quest",
        port: 8812,
        user: "admin",
    });

    try {
        await client.connect();

        const result = await client.query("SELECT value as number,traded_ts as time FROM java_data where uuid like '7f091d9a-b22f-45c6-a2c7-9126c98465cd';");

        res.json({ status: "success", data: result.rows });
    } catch (error) {
        console.error("Error executing query:", error);
        res.status(500).json({ status: "error", message: "Internal Server Error" });
    } finally {
        await client.end();
    }
});