import json

from questdb.ingress import Sender, IngressError, TimestampNanos
import sys
import datetime

import pika, sys, os

my_dictionary = {}


def sent_to_questdb(timestamp, value, uuid, host: str = 'localhost', port: int = 9009):
    try:
        with Sender(host, port) as sender:
            sender.row(
                'java_data',
                columns={
                    'value': value,
                    'uuid': uuid,
                    'traded_ts': datetime.datetime(
                        int(timestamp[0:4]), int(timestamp[5:7]), int(timestamp[8:10]), int(timestamp[11:13]), int(timestamp[14:16]), int(timestamp[17:19]), 000000,
                        tzinfo=datetime.timezone.utc)},
                at=TimestampNanos.now())
            sender.flush()

    except IngressError as e:
        sys.stderr.write(f'Got error: {e}\n')


def sent_to_questdb_aggregated(timestamp, value, uuid, host: str = 'localhost', port: int = 9009):
    try:
        with Sender(host, port) as sender:
            sender.row(
                'aggregated_data',
                columns={
                    'value': value,
                    'uuid': uuid,
                    'traded_ts': datetime.datetime(
                        int(timestamp[0:4]), int(timestamp[5:7]), int(timestamp[8:10]), 0, 0, 0, 000000,
                        tzinfo=datetime.timezone.utc)},
                at=TimestampNanos.now())
            sender.flush()

    except IngressError as e:
        sys.stderr.write(f'Got error: {e}\n')


def main():
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()

    channel.queue_declare(queue='pliroforiaka', durable=True)

    print(' [*] Waiting for messages. To exit press CTRL+C')

    def callback(ch, method, properties, body):
        python_dict = json.loads(body)
        if(python_dict['uuid'] == '7f091d9a-b22f-45c6-a2c7-9126c98465cd' or python_dict['uuid'] == '7f091d9a-b22f-45c6-a2c7-9126c98465ce' or python_dict['uuid'] == '7f091d9a-b22f-45c6-a2c7-9126c98465cf' or python_dict['uuid'] == '7f091d9a-b22f-45c6-a2c7-9126c98465d0' or python_dict['uuid'] == '7f091d9a-b22f-45c6-a2c7-9126c98465d1' or python_dict['uuid'] == '7f091d9a-b22f-45c6-a2c7-9126c98465d2' or python_dict['uuid'] == '7f091d9a-b22f-45c6-a2c7-9126c98465d4' or python_dict['uuid'] == '7f091d9a-b22f-45c6-a2c7-9126c98465d5'):
            if(python_dict['uuid'] in my_dictionary):
                n1 = int(python_dict['value']) + int(my_dictionary.get(python_dict['uuid']))
                my_dictionary[python_dict['uuid']] = n1
            else:
                my_dictionary[python_dict['uuid']] = python_dict['value']
        else:
            if (python_dict['uuid'] in my_dictionary):
                n1 = int(python_dict['value'])
                if n1 > int(my_dictionary.get(python_dict['uuid'])):
                    my_dictionary[python_dict['uuid']] = n1
                    sent_to_questdb_aggregated(python_dict['timestamp'], my_dictionary.get(python_dict['uuid']) - n1, python_dict['uuid'])
            else:
                my_dictionary[python_dict['uuid']] = python_dict['value']



        sent_to_questdb(python_dict['timestamp'], python_dict['value'], python_dict['uuid'])

        temp_timestamp = python_dict['timestamp']

        if temp_timestamp[11:16] == '23:45':
            if python_dict['uuid'] == '7f091d9a-b22f-45c6-a2c7-9126c98465cd' or python_dict['uuid'] == '7f091d9a-b22f-45c6-a2c7-9126c98465ce':
                sent_to_questdb_aggregated(python_dict['timestamp'], my_dictionary.get(python_dict['uuid']), python_dict['uuid'])
                my_dictionary[python_dict['uuid']] = 0
            if python_dict['uuid'] == '7f091d9a-b22f-45c6-a2c7-9126c98465cf' or python_dict['uuid'] == '7f091d9a-b22f-45c6-a2c7-9126c98465d0' or python_dict['uuid'] == '7f091d9a-b22f-45c6-a2c7-9126c98465d1' or python_dict['uuid'] == '7f091d9a-b22f-45c6-a2c7-9126c98465d2' or python_dict['uuid'] == '7f091d9a-b22f-45c6-a2c7-9126c98465d4' or python_dict['uuid'] == '7f091d9a-b22f-45c6-a2c7-9126c98465d5':
                sent_to_questdb_aggregated(python_dict['timestamp'], my_dictionary.get(python_dict['uuid']), python_dict['uuid'])
                my_dictionary[python_dict['uuid']] = 0



    channel.basic_consume(queue='pliroforiaka', on_message_callback=callback, auto_ack=True)

    print(' [*] Waiting for messages. To exit press CTRL+C')
    channel.start_consuming()

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('Interrupted')
        try:
            sys.exit(0)
        except SystemExit:
            os._exit(0)
