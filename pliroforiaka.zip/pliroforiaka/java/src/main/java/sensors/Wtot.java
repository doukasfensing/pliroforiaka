package sensors;

public class Wtot extends Sensor{
    public void setValue(){
        double d1 = Math.random();
        if(d1 > 0.5)
            this.value += 110 + 10;
        else
            this.value += 110 - 10;
    }
}
