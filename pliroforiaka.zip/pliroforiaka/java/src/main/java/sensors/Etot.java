package sensors;

public class Etot extends Sensor{
    @Override
    public void setValue(){
        double d1 = Math.random();
         if(d1 > 0.5)
             this.value += 2600 * 24 + 1000;
         else
             this.value += 2600 * 24 - 1000;
    }
}
