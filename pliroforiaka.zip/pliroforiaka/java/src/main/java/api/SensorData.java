package api;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@lombok.Data
@AllArgsConstructor
@NoArgsConstructor
public class SensorData {
    @JsonProperty("uuid")
    private String uuid;

    @JsonProperty("value")
    private double value;

    @JsonProperty("timestamp")
    private String timestamp;
}
